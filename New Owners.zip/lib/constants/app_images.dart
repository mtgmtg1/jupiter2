class AppImages {
  static const appLogo = "assets/images/app_icon.png";
  static const user = "assets/images/user.png";
  static const forgotPasswordImage = "assets/images/forgot_pasword.png";
  static const loginImage = "assets/images/login_intro.png";
  static const registerImage = "assets/images/register_intro.jpg";

  //
  static const onboarding1 = "assets/images/1.png";
  static const onboarding2 = "assets/images/2.png";
  static const onboarding3 = "assets/images/3.png";
}
