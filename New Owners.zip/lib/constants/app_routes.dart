class AppRoutes {
  static const welcomeRoute = "welcome";
  static const loginRoute = "login";
  static const editProfileRoute = "edit_profile";
  static const registerRoute = "register";
  static const forgotPasswordRoute = "forgot_password";
  static const homeRoute = "home";
  static const notificationsRoute = "notificaitions";
  static const notificationDetailsRoute = "notificaition_details";
}
