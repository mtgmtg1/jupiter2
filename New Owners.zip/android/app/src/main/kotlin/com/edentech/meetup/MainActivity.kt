package com.edentech.meetup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
